#include<iostream>
#include<stdlib.h>
using namespace std;

string num_dividido(string numero, int n);
int suma(string numero,int n);

int main(){

    string cadena,numero_separado;
    cin>>cadena;
    int n;
    cin>>n;

    cout<<"Ingrese su cadena de numeros: ";
    numero_separado=num_dividido(cadena,n);
    cout<<"Ingrese el numero para separar: ";
    cout<<suma(numero_separado,n);

    return 0;
}


    //como se me divide el numero
string num_dividido(string numero, int n){

    if(numero.size()%n==0){
        return numero;
    }else{

        string ceros="";
        string copia_numero=numero;

        while(copia_numero.size()%n!=0){
            ceros+="0";
            copia_numero=ceros+numero;
        }
    return copia_numero;
    }
}

int suma(string numero,int n){


    int sumaTotal=0;
    string num_aux="";

    for(int i=0;i<numero.size();i++){
        num_aux+=numero[i];

        if((i+1)%n==0){
            sumaTotal+=atoi(num_aux.c_str());
            num_aux="";

        }
    }
    return sumaTotal;
}

