#include <iostream>
#include <stdlib.h>
using namespace std;


void pedirDatos();
void MostrarMatriz(int **, int, int);
int EsEstrella(int **puntero_matriz);

char imgDigital[48]={0,3,4,0,0,0,6,8,5,13,6,0,0,0,2,3,2,6,2,7,3,0,10,0,0,0,4,15,4,1,6,0,0,0,7,12,6,9,10,4,5,0,6,10,6,4,8,0};
int **puntero_matriz, nCol=8, nFilas=6, cont=0;
float sumaEstrellas=0.0, totalEstrellas=0.0;

int main()
{
    cout << "Problema 15" << endl;
    pedirDatos();
    MostrarMatriz( puntero_matriz, nFilas, nCol);
    cout<<endl<<"El numero total de estrellas es "<<EsEstrella(puntero_matriz)<<endl<<endl;

    //liberar memoria
    for(int i=0;i<nFilas;i++){
        delete[] puntero_matriz[i];//columnas
    }
    delete[] puntero_matriz;

    return 0;
}
void pedirDatos(){


    //Reservar memoria para la matriz dinamica
    puntero_matriz= new int*[nFilas];//reservando memoria de filas, necesita puntero porque las filas señalan a las correspondientes col
    for(int i=0;i<nFilas;i++){
        puntero_matriz[i]= new int[nCol];
    }


    for(int i=0;i<nFilas;i++){
        for(int j=0;j<nCol;j++){

            *(*(puntero_matriz+i)+j)=(imgDigital[cont]);//puntero matriz[i][j]
            cont++;
        }
    }
}

void MostrarMatriz(int **puntero_matriz, int nFilas, int nCol){
    cout<<endl<<endl<<"Imagen digital"<<endl<<endl;
    for(int i=0;i<nFilas;i++){
        for(int j=0;j<nCol;j++){
            cout<<*(*(puntero_matriz+i)+j)<<"  ";
        }
        cout<<endl;
    }
    cout<<endl;

   /*for(int i=1;i<5;i++){
        for(int j=1;j<7;j++){
            cout<<*(*(puntero_matriz+i)+j)<<"  ";
        }
        cout<<endl;
    }
    cout<<endl;
    cout<<endl;
*/
}

int EsEstrella(int **puntero_matriz){

    cout<<endl;
    for(int i=1;i<5;i++){
        for(int j=1;j<7;j++){
            sumaEstrellas=(*(*(puntero_matriz+i)+j))+(*(*(puntero_matriz+i)+j-1))+(*(*(puntero_matriz+i)+j+1))+(*(*(puntero_matriz+i-1)+j))+(*(*(puntero_matriz+i+1)+j));
            sumaEstrellas= sumaEstrellas/5;

            if (sumaEstrellas>6){
                //cout<<endl<<sumaEstrellas<<endl;
                totalEstrellas++;
            }
        }
    }

    return totalEstrellas;
}



