#include <iostream>
using namespace std;

void fun_a(int *px, int *py);
void fun_b(int a[], int tam);

int main()
{
    int array[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    int *pt= &array[0];//dirección en memoria del array
    cout<< pt;

    fun_b(array, 10);

}
void fun_a(int *px, int *py){
    int tmp = *px;
    *px = *py;
    *py = tmp;

}
void fun_b(int a[], int tam){
    int f, l;
    int *b = a;

    for (f = 0, l = tam -1; f < l; f++, l--) {
        fun_a(&b[f], &b[l]);
    }
}

/*
Cuál es su dirección en memoria?
-> 0x61fdf0

¿Cuántos bytes se dedican para almacenar cada elemento de array?
-> 4

Cuál es la dirección y el contenido en memoria del elemento array[3] ?
-> La dirección es 0x61fdfc y el contenido es 3.

Describa el efecto que tiene la función fun_b, sobre el arreglo array.
->Esta funcion recurre a través de un for a otra función (fun_a), la cual recorre
  mediante apuntadores los elementos del array. f empieza en el primero y l en el ultimo
  hasta encontrarse a la mitad del arreglo


*/
