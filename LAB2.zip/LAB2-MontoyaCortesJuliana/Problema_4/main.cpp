#include <iostream>
using namespace std;

int ConvertirCadenaAInt(string numstring);

int main()
{
    cout << "Problema 4" << endl;
    string numCadena;
    cout<<"Ingrese su numero: ";
    cin>>numCadena;
    ConvertirCadenaAInt(numCadena);

    return 0;
}

int ConvertirCadenaAInt(string numstring){
    int numInt = 0;


    numInt = stoi(numstring);
    cout << "Numero entero con valor " << numInt <<endl;

    return numInt;
}
