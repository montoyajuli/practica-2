#include <iostream>

using namespace std;

int main()
{
    cout << "ingrese el numero" << endl;
    int num=220, suma=0;
    //cin>>num;



    for (int i=1;i<num;i++){
        if(num%i==0){
            suma=i+suma;
            cout<<suma<<endl;
        }
    }
    return 0;
}
