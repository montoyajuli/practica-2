#include <iostream>

using namespace std;


int main(){
    int num;
    cout<<"Ingrese un num: ";
    cin>>num;

    int factorial1=1;
    int factorial2=1;

    for(int j=1;j<=2*num;j++){
        factorial1*=j;
    }

    for(int i=1;i<=num;i++){
        factorial2*=i;
    }

    cout<<"Para una malla de "<<num<<"X"<<num<<" hay "<<(factorial1)/((factorial2)*(factorial2))<<" caminos."<<endl;

}
