#include <iostream>
#include <string>
using namespace std;

string deInt_aStr(int n);

int main()
{
    cout << "Problema 5" << endl;

    int num;
    string cadena;
    cout<<"Ingresa un numero: ";
    cin>>num;
    cadena =deInt_aStr(num);

    return 0;
}

string deInt_aStr(int n){

    string str = to_string(n);
    cout<<str<<endl;
    return str;
}
