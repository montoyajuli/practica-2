#include <iostream>

using namespace std;

int main()
{

    unsigned short b[4][2] = {{77, 50}, {5, 2}, {28, 39}, {99, 3}};

    unsigned short *ptr;
    ptr=&b[0][0];
    cout<<ptr;

    return 0;
}
