#include <iostream>
#include <string.h>

using namespace std;

void separarNumsyLetras(char cadOriginal[]);

int main()
{
    cout << "Problema_8" << endl;
    char C_Original[30];

    cout << "Ingrese su cadena de caracteres: " ;
    cin>>C_Original;
    separarNumsyLetras(C_Original);
    return 0;
}
void separarNumsyLetras(char cadOriginal[]){

    char cadLetras[30]={};
    char cadNum[30]={};

    int longit=strlen(cadOriginal);
    int contletras=0, contnum=0;

    for(int i=0;i<longit;i++){
        if ((char (cadOriginal[i])) <123 and (char (cadOriginal[i])) >96){
            cadLetras[contletras]=cadOriginal[i];
            contletras++;
        }

        else if((char (cadOriginal[i])) != (123>96)){
            cadNum[contnum]=cadOriginal[i];
            contnum++;
        }
    }


    int tamletras=strlen(cadLetras);
    for(int j=0;j<tamletras;j++){
        cout <<cadLetras[j];
    }
    cout <<endl;

    int tamnum=strlen(cadNum);
    for(int l=0;l<tamnum;l++){
        cout <<cadNum[l];
    }
    cout <<endl;
}
