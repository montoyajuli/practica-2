#include <iostream>

using namespace std;

int main()
{
    int i[3]={2,3,6};
    int *ptr;

    ptr = &i[0];

    int C_separados[30]={1,2,3};


    for(int r; r<3; r++){
        cout<<C_separados[r]<<endl;
    }




    /*

    char texto = 98;
    cout <<char(texto)<<endl;


    char texto1 = 'A';
    if (texto1>=97 and texto1<=122){
        cout <<"Si"<<endl;
    }
    char ran='A';


    if (ran=='A'){
        cout<<"si";
    }


    char a[20];
    cin>>a[20];
    int length = sizeof(a[20])/sizeof(char);


    */
    return 0;


}
