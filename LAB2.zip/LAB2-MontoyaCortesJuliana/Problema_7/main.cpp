#include <iostream>
#include <string.h>

using namespace std;

void eliminaRepetidos(char cadena[]);

int main()
{
    cout << "Problema 7 -- Elimina elementos repetidos" << endl;

    char caracteres[35];
    string laOtraCadena;
    cout<<"Ingrese su cadena de caracteres: ";
    cin>>caracteres;
    eliminaRepetidos(caracteres);

    return 0;
}
void eliminaRepetidos(char cadena[]){
    int longit=0;
    longit=strlen(cadena)+2;


    for (int i=0;i<longit;i++){

        for(int l=i+1;l<longit;l++){
            if (cadena[i]==cadena[l] or cadena[i]==char(cadena[l]-32) or cadena[i]==char(cadena[l]+32) ){

                for (int j=l; j<longit;j++){
                    cadena[j]=cadena[j+1];

                    l=i;
                    longit-=1;
                }
            }
        }
    }

    for(int m=0;m<longit;m++){
        cout<<cadena[m];
    }
    cout<<endl;

}
