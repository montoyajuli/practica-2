#include <iostream>
#include <string.h>

using namespace std;


int main()
{
    char cadena[]= "Mango";
    strupr(cadena);
    cout<<cadena<<endl;
    return 0;

}
