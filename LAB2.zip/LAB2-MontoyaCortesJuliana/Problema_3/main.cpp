#include <iostream>
#include <string.h>

using namespace std;

bool palabrasiguales(char p1[], char p2[]);

int main()
{
    cout << "Problema 3" << endl;

    char palab1[15] = "", palab2[15]="";

    cout<<"Ingrese la primera palabra: ";
    cin>>palab1;


    cout<<"Ingrese la segunda palabra: ";
    cin>>palab2;

    bool v_log = palabrasiguales(palab1, palab2);
    cout<<v_log<<endl;

    return 0;
}
bool palabrasiguales(char p1[], char p2[]){

    bool parafor=false;

     int longitud= 0, cont=0;
    longitud= strlen(p1);

    for(int i=0;i<longitud;i++){
        if (p1[i]==p2[i]){
            parafor=true;

        }
        else{
            cont++;
        }
    }

    if (cont>0){
        parafor=false;
    }


    if (parafor==true){
        cout<<endl<<"Verdadero"<<endl;
    }
    else{
        cout<<endl<<"Falso"<<endl;
    }

    return parafor;

}
