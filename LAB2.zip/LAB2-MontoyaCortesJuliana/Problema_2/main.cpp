#include <iostream>
#include <stdlib.h>
#include <ctime>

using namespace std;

int main()
{
    int A=0,B=0,C=0,D=0,E=0,F=0,G=0,H=0,I=0,J=0,K=0,L=0,M=0,N=0,O=0;
    int P=0,Q=0,R=0,S=0,T=0,U=0,V=0,W=0,X=0,Y=0,Z=0;
    cout<<"Letras aleatorias: ";
    char ran;

    srand(time(NULL));
    char letras[26]={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O',
                     'P','Q','R','S','T','U','V','W','X','Y','Z'};

    for(int i=0;i<200;i++){
        ran=letras[rand()%26];
        cout<<ran;
        if (ran=='A'){
            A++;
        }

        else if(ran=='B'){
            B++;
        }
        else if(ran=='C'){
            C++;
        }
        else if(ran=='D'){
            D++;
        }
        else if(ran=='E'){
            F++;
        }
        else if(ran=='G'){
            G++;
        }
        else if(ran=='H'){
            H++;
        }
        else if(ran=='I'){
            I++;
        }
        else if(ran=='J'){
            J++;
        }
        else if(ran=='K'){
            K++;
        }
        else if(ran=='L'){
            L++;
        }
        else if(ran=='M'){
            M++;
        }
        else if(ran=='N'){
            N++;
        }
        else if(ran=='O'){
            O++;
        }
        else if(ran=='P'){
            P++;
        }
        else if(ran=='Q'){
            Q++;
        }
        else if(ran=='R'){
            R++;
        }
        else if(ran=='S'){
            S++;
        }
        else if(ran=='T'){
            T++;
        }
        else if(ran=='U'){
            U++;
        }
        else if(ran=='V'){
            V++;
        }
        else if(ran=='W'){
            W++;
        }
        else if(ran=='X'){
            X++;
        }
        else if(ran=='Y'){
            Y++;
        }
        else if(ran=='Z'){
            Z++;
        }

    }
    cout<<endl<<'A'<<": "<<A<<endl;
    cout<<'B'<<": "<<B<<endl;
    cout<<'C'<<": "<<C<<endl;
    cout<<'D'<<": "<<D<<endl;
    cout<<'E'<<": "<<E<<endl;
    cout<<'F'<<": "<<F<<endl;
    cout<<'G'<<": "<<G<<endl;
    cout<<'H'<<": "<<H<<endl;
    cout<<'I'<<": "<<I<<endl;
    cout<<'J'<<": "<<J<<endl;
    cout<<'K'<<": "<<K<<endl;
    cout<<'L'<<": "<<L<<endl;
    cout<<'M'<<": "<<M<<endl;
    cout<<'N'<<": "<<N<<endl;
    cout<<'O'<<": "<<O<<endl;
    cout<<'P'<<": "<<P<<endl;
    cout<<'Q'<<": "<<Q<<endl;
    cout<<'R'<<": "<<R<<endl;
    cout<<'S'<<": "<<S<<endl;
    cout<<'T'<<": "<<T<<endl;
    cout<<'U'<<": "<<U<<endl;
    cout<<'V'<<": "<<V<<endl;
    cout<<'W'<<": "<<W<<endl;
    cout<<'X'<<": "<<X<<endl;
    cout<<'Y'<<": "<<Y<<endl;
    cout<<'Z'<<": "<<Z<<endl;


}
